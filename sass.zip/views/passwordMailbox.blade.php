<head><title>Picruit</title></head>
<body>

    <p>Hi there,
          </p>
    <p>  This is your Picruit admin</p>
   
 <h2>{{$data['subject']}} </h2> 
<p>{{$data['body']}} </p>
<h4>{{$data['userEmail']}}</h4>
    {{-- <h3>{{$data['body']}}</h3> --}}
   
</body>